from dynamic_fc import dyn_fewest_coins # Dynamic prog soln used for quick testing

def fewest_coins_greedy(amt, coins):
    """Returns the fewest number of coins required to make amt with the given list coins.
    """
    

def fewest_coins_recr(amt, coins):
    """Recurisve solution will explore every possible path"""

def fewest_coins_memo(amt, coins):
    """Recursive, but uses memoization to avoid redundant solutions"""

if __name__ == '__main__':
    fns = [fewest_coins_greedy, fewest_coins_recr, fewest_coins_memo]
    for amt in [50, 63]:
        print(f"amt = {amt}")
        for coins in [[1, 5, 10, 25], [1, 5, 10, 21, 25]]:
            print(f"\tcoins = {coins}")
            for fn in fns:
                try:
                    assert fn(amt, coins) == dyn_fewest_coins(amt, coins)
                    print(f"\t\t{fn.__name__} works!")

                except AssertionError:
                    print(f"\t\t{fn.__name__} fails.")
