class EdgeSet:
    def __init__(self, V, E): pass

    def add_vertex(self, v): pass

    def add_edge(self, e): pass

    def is_connected(self, v1, v2): pass

    def nbrs(self, v): pass
        

if __name__ == '__main__':
    #############################################
    #                                           #
    #                                Portland   #
    #                               / 114 miles #
    #                              /            #
    #               ____________Boston          #
    #     101 miles_/         _/                #
    #            _/          /    85 miles      #
    #           /           |                   #
    #        Hartford------Storrs               #
    #       /           27 mi                   #
    #      / 117 mi                             #
    #     /                                     #
    #   NYC                                     #
    #                                           #
    #   DC                                      #
    #                                           #
    #############################################
    Graph = EdgeSet # Use EdgeSet as our data struture
    V = # create a set of vertices
    E = # create a set of edges (ignore weights for now)
    g = Graph(V, E)

    # Test some True's from `NYC`
    for city in ['Hartford', 'Storrs', 'Boston', 'Portland']:
        print(f"Testing g.is_connected('NYC', {city})")
        assert g.is_connected('NYC', city)
        print(f"g.is_connected('NYC', {city}) works!\n")

        print(f"Testing g.is_connected({city}, 'NYC')")
        assert g.is_connected(city, 'NYC')
        print(f"g.is_connected({city}, 'NYC') works!\n")
    
    # Test a False from `NYC`
    print(f"Testing not g.is_connected('NYC', 'DC')")
    assert not g.is_connected('NYC', 'DC')
    print(f"not g.is_connected('NYC', 'DC') works!\n")

    print(f"Testing not g.is_connected('NYC', 'DC')")
    assert not g.is_connected('DC', 'NYC')
    print(f"not g.is_connected('NYC', 'DC') works!\n")